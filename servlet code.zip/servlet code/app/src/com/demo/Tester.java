package com.demo;

class A {
	public String type = "x";

	public A() {
		System.out.println("alpha");
	}

}



public class Tester extends A {
	public String type = "y";
	public Tester(){
		System.out.println("beta");
	}

	void go(){
		final  String type="b";
		
		System.out.println(this.type+ " : "+ super.type);
	}
	public static void main(String[] args) {

		new Tester().go();
	}

}
