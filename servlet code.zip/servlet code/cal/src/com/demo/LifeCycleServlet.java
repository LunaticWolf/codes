package com.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
// AtomicInteger vs syn of integer data on SO
public class LifeCycleServlet extends HttpServlet {
	private static int counter=0;
	private static AtomicInteger atomicInteger=new AtomicInteger(0);
	private static final long serialVersionUID = 1L;

	public LifeCycleServlet() {
		System.out.println("ctr of servlet....");
	}
	

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		//ServeletContext vs ServletConfig
		String fileName=config.getInitParameter("fileName");
		
		System.out.println("init of servlet...."+ fileName);
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	
		
		PrintWriter out=response.getWriter();
		out.print(atomicInteger.addAndGet(1));
		
		destroy();
		

	}

	@Override
	public void destroy() {
		super.destroy();
		//Dont forget to write it into file!
		System.out.println("destroy of servlet....");
	}

}
