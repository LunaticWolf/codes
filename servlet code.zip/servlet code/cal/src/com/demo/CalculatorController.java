package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CalculatorController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CalculatorController(){
		System.out.println("ctr of CalculatorController is called..");
	}
	
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException 
	{
		
		response.setContentType("text/html");
		
		Integer firstNo=Integer.parseInt(request.getParameter("firstNo"));
		Integer secondNo=Integer.parseInt(request.getParameter("secondNo"));
		Integer result=firstNo+ secondNo;
	
		PrintWriter out=response.getWriter();
		out.print(result +"<br/>");
	}


}
/**
 * 
 * 
1xx information
2xx 200 success 201: created resource successfully 202 203
3xx redirect
4xx client side error 
5xx server side error

 */
