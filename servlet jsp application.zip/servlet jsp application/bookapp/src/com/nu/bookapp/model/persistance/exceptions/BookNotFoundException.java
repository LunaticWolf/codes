package com.nu.bookapp.model.persistance.exceptions;

public class BookNotFoundException extends Exception{
	private static final long serialVersionUID = 9185753666208877780L;

}
