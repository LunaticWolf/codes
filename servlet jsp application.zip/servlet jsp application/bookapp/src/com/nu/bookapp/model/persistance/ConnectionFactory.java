package com.nu.bookapp.model.persistance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConnectionFactory {
	private static Connection connection=null;
	public static Connection getConnection(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver is loaded...");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1:3306/nu5", "root", "root");
		}catch(SQLException e){
			e.printStackTrace();
			//logging log4j*
		}
		
		return connection;
	}
}
