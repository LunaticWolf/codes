package com.nu.bookapp.model.persistance.exceptions;

public class DaoException extends Exception{
	private static final long serialVersionUID = 8492388684784280812L;

	public DaoException(String message, Throwable cause) {
		super(message, cause);
	}
}
