package com.nu.bookapp.model.persistance;
import java.util.List;

import com.nu.bookapp.model.persistance.exceptions.BookNotFoundException;
import com.nu.bookapp.model.persistance.exceptions.DaoException;
//5 CRUD + findById
public interface BookDao {

	public void addBook(Book book)throws DaoException;
	public List<Book> getAllBooks()throws DaoException;
	public void deleteBook(String bookId)throws DaoException;
	public Book getBookById(String bookId)throws DaoException, BookNotFoundException;
	
	
}
