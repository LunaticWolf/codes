package com.nu.bookapp.model.persistance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.nu.bookapp.model.persistance.exceptions.BookNotFoundException;
import com.nu.bookapp.model.persistance.exceptions.DaoException;

public  class BookDaoImpUsingJdbc implements BookDao{
	private Connection connection;
	
	public BookDaoImpUsingJdbc(Connection connection){
		this.connection=connection;
		
	}
	@Override
	public void addBook(Book book)throws DaoException {
		try {
			PreparedStatement pstmt = connection
					.prepareStatement
					("insert into BOOKS(isbn, author, title, price)values(?,?,?,?)");
		

			pstmt.setString(1, book.getIsbn());
			pstmt.setString(2, book.getAuthor());
			pstmt.setString(3, book.getTitle());
			pstmt.setFloat(4, book.getPrice());
			
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new DaoException("some jdbc hell", e);
		}

	}

	@Override
	public List<Book> getAllBooks()throws DaoException {
		return null;
	}

	@Override
	public void deleteBook(String bookId) throws DaoException{
		
	}

	@Override
	public Book getBookById(String bookId)throws DaoException, BookNotFoundException {
		return null;
	}

}
