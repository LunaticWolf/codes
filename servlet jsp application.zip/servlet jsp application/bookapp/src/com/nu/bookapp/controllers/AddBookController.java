package com.nu.bookapp.controllers;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nu.bookapp.model.persistance.Book;
import com.nu.bookapp.model.persistance.BookDao;
import com.nu.bookapp.model.persistance.BookDaoImpUsingJdbc;
import com.nu.bookapp.model.persistance.ConnectionFactory;
import com.nu.bookapp.model.persistance.exceptions.DaoException;

public class AddBookController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connection = null;
	private BookDao bookDao;
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		connection = ConnectionFactory.getConnection();
		bookDao=new BookDaoImpUsingJdbc(connection);

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/jsp/addbook.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String isbn = request.getParameter("isbn");
		String author = request.getParameter("author");
		String title = request.getParameter("title");
		Float priceStr = Float.parseFloat(request.getParameter("price"));

		Book book=new Book(isbn, title, author, priceStr);
		
		try {
			bookDao.addBook(book);
			
		} catch (DaoException e) {
			e.printStackTrace();
		}
		
		request.setAttribute("book", book);
		
		RequestDispatcher rd=request.getRequestDispatcher("/WEB-INF/jsp/show.jsp");
		rd.forward(request, response);
		
		// RequestDispahcer vs sendRedirect
		
	}

	@Override
	public void destroy() {
		super.destroy();
	}

}
// to add data to that table

// MVC:
/*
 * 1. get data from ui 2. change the data type if required 3. do validation on
 * server side
 * 
 * 4. call BL => persistance layer
 * 
 * 5. then servlet put this processing result in jsp 6. then servlet user
 * requestDispahcer to add data to request scope
 * 
 * then 7. jsp show the data 8. flow end
 */

