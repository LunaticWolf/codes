package com.nu.bookapp.controller;

import java.sql.Connection;

import com.nu.bookapp.model.persistance.Book;
import com.nu.bookapp.model.persistance.BookDao;
import com.nu.bookapp.model.persistance.BookDaoImpl;
import com.nu.bookapp.model.persistance.connectionfactory.ConnectionFactory;
import com.nu.bookapp.model.persistance.exceptions.DaoException;
import com.nu.bookapp.model.service.BookService;
import com.nu.bookapp.model.service.BookServiceImpl;

public class Main {
	
	public static void main(String[] args) {
		
		Connection connection=ConnectionFactory.getConnection();
		BookDao bookDao=new BookDaoImpl(connection);
		BookService bookService=new BookServiceImpl(bookDao);
		
		if(connection!=null)
			System.out.println("conn is done");
		
		try {
			bookService.addBook(new Book("565", "java is fun", "college teacher", 590));
		} catch (DaoException e) {
			e.printStackTrace();
		}
	}

}
