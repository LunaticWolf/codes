package com.nu.bookapp.controller.listner;

import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.nu.bookapp.model.persistance.connectionfactory.ConnectionFactory;

public class ConnectionInitilizerLister implements ServletContextListener {

	private Connection connection=null;
	
    public void contextInitialized(ServletContextEvent event)  { 
         
    	connection=ConnectionFactory.getConnection();
    	event.getServletContext().setAttribute("connection", connection);
    }
   
    public void contextDestroyed(ServletContextEvent event)  { 
        event.getServletContext().removeAttribute("connection");
        if(connection!=null)
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    }

}
