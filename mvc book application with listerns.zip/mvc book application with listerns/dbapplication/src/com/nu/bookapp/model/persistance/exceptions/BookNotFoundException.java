package com.nu.bookapp.model.persistance.exceptions;

public class BookNotFoundException extends  Exception {

	private static final long serialVersionUID = 8202122674791761752L;

	public BookNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
