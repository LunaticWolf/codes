package com.nu.bookapp.model.persistance.connectionfactory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	private static Connection connection = null;

	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1:3306/nu5", "root", "root");

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}
}
