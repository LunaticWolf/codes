package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class S2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// PrintWriter out=response.getWriter();
		// 
		PrintWriter out = response.getWriter();
		out.print("hello by S2");
		RequestDispatcher rd = request.getRequestDispatcher("/S3");
		//rd.forward(request, response);
		rd.include(request, response);
	}

}
