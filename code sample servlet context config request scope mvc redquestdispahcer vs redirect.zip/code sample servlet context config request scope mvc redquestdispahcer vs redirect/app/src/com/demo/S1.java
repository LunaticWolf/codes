package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class S1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		//
		// init para: context config => constant ==> can not change
		
		//scope: req ,session, application scope(conext scope)
		
		PrintWriter out=response.getWriter();
		out.print("hello by S1");
		
		RequestDispatcher rd=request.getRequestDispatcher("/S2");
		
		request.setAttribute("name", "raj");
		//rd.forward(request, response);
		rd.include(request, response);
		
		//rd.forward(request, response);
		//response.sendRedirect("S2");
	}

}










