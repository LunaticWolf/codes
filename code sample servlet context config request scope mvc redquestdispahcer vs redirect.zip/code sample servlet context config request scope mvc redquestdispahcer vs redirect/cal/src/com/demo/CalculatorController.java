package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Calculator;


public class CalculatorController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CalculatorController(){
		System.out.println("ctr of CalculatorController is called..");
	}
	
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException 
	{
		
		Integer firstNumber=null;
		Integer secondNumber=null;
		response.setContentType("text/html");
		//Controller => must accept data from user/clint=> 
		//convert the data=>to proper data formate
		// then it should talk to model layer => BL to calculate sum
		
		
		try{
			firstNumber=Integer.parseInt(request.getParameter("firstNo"));
			 secondNumber=Integer.parseInt(request.getParameter("secondNo"));
		
		}catch(Exception e){
			request.setAttribute("error", "invalid data");
			RequestDispatcher rd=request.getRequestDispatcher("cal.jsp");
			rd.forward(request, response);
		}
		//MVC! => model view and controller!
		
		//X
		//Integer result=firstNo+ secondNo;
		Integer result=Calculator.sum(firstNumber, secondNumber);
		// now controller put this data in request scope
		request.setAttribute("result", result);
		RequestDispatcher rd=request.getRequestDispatcher("show.jsp");
		rd.forward(request, response);
		//PrintWriter out=response.getWriter();
		//out.print(result +"<br/>");
	}


}
/**
 * 
 * 
1xx information
2xx 200 success 201: created resource successfully 202 203
3xx redirect
4xx client side error 
5xx server side error

 */
