package com.model;

public class Calculator {
	public static Integer sum(Integer firstNumber, Integer secondNumber){
		return firstNumber+ secondNumber;
	}
}
