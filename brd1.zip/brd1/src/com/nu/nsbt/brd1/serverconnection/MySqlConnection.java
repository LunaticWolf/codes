package com.nu.nsbt.brd1.serverconnection;

//package Connection;

import java.sql.Connection;


public class MySqlConnection implements ConnectionI  {

	//@Override
	public Connection myConnection() 
	{
		
		return null;
	}

}
