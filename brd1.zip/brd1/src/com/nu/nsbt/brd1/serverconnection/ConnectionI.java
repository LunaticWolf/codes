package com.nu.nsbt.brd1.serverconnection;

//package Connection;

import java.sql.Connection;

//Establishing Connection 
public interface ConnectionI 
{

	public Connection myConnection();
	
}
