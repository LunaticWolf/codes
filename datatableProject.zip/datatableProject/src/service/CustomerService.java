package service;

import java.util.ArrayList;

import daoOperation.Dao;
import entityPojo_customer.Customer;

public class CustomerService
{
	public ArrayList<Customer> viewCustomer()
	{
		Dao dao=new Dao();
		ArrayList<Customer> customers=dao.fetchAll();
		return customers;
		
		
	}
}
