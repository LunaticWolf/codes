package daoOperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connection.ConnectionI;
import connection.OracleConnection;
import entityPojo_customer.Customer;

public class Dao 
{
	Connection conn=null;
	ConnectionI c=null;
	public ArrayList<Customer> fetchAll()
	{
		
		c=new OracleConnection();
		conn=c.myConnection();
		Statement stmt=null;
		ResultSet rs=null;
		
		ArrayList<Customer> customer=new ArrayList<Customer>();
			try 
			{
				stmt=conn.createStatement();
				rs=stmt.executeQuery("select * from acustomer_master");
				while(rs.next())
				{
					Customer c=new Customer();
					c.setCustomer_id(rs.getInt(1));
					c.setCustomer_code(rs.getString(2));
					c.setCustomer_name(rs.getString(3));
					c.setCustomer_address1(rs.getString(4));
					c.setCustomer_address2(rs.getString(5));
					c.setCustomer_pinCode(rs.getInt(6));
					c.setEmail_address(rs.getString(7));
					c.setContact_number(rs.getString(8));
					c.setPrimaryConatctPerson(rs.getString(9));
					c.setRecord_status(rs.getString(10));
					c.setActive_inactiveFlag(rs.getString(11));
					c.setCreate_date(rs.getString(12));
					c.setCreated_by(rs.getString(13));
					c.setModified_date(rs.getString(14));
					c.setModified_by(rs.getString(15));
					c.setAuthorized_date(rs.getString(16));
					c.setAuthorized_by(rs.getString(17));
					customer.add(c);	
				}
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
				return customer;
		
	}
	
	public boolean fetchUser(String u,String p) throws SQLException
	{
		c=new OracleConnection();
		conn=c.myConnection();
		
		PreparedStatement ps=conn.prepareStatement("select * from auser where username=? and password=?");  
		ps.setString(1,u);  
		ps.setString(2,p);  
	      
		ResultSet rs=ps.executeQuery();  
		boolean status=rs.next();
		return status;  
		
	}
}
