package connection;

import java.sql.Connection;

public class MySQL implements ConnectionI  {

	@Override
	public Connection myConnection() {
		
		return null;
	}

}
