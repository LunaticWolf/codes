package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entityPojo_customer.Customer;
import service.CustomerService;

@WebServlet("/CustomerController")
public class CustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		CustomerService service=new CustomerService();
		String action=request.getParameter("action");
		HttpSession session=request.getSession(false);
		
		if(session.getAttribute("name")!=null)
		{
		if(action.equalsIgnoreCase("view"))
		{
		ArrayList<Customer> customer=service.viewCustomer();
		request.setAttribute("customers", customer);
	    RequestDispatcher rd=request.getRequestDispatcher("ViewCustomer.jsp");
		rd.forward(request, response);
		}
		else if(action.equalsIgnoreCase("add"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("addCustomer.jsp");
			rd.forward(request, response);
			/*int a=service.add(request.getParameter("code"),request.getParameter("name"),request.getParameter("add1"),request.getParameter("add2"),request.getParameter("pincode")
					,request.getParameter("email"),request.getParameter("contact"),request.getParameter("primary"),request.getParameter("record"),request.getParameter("flag")
					,request.getParameter("cdate"),request.getParameter("cby"),request.getParameter("mdate"),request.getParameter("mby"),request.getParameter("adate"),request.getParameter("aby"));
			*/
		}
		
		else if(action.equalsIgnoreCase("update"))
		{
			PrintWriter pw=response.getWriter();
			pw.print("update");
		}
		
		else if(action.equalsIgnoreCase("delete"))
		{
			PrintWriter pw=response.getWriter();
			pw.print("delete");
		}
		else
		{
			session.invalidate();
			RequestDispatcher rd=request.getRequestDispatcher("logout.jsp");
			rd.forward(request, response);
		}
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("login.html");
			rd.forward(request, response);
		}
	}
	}
		
	
	
	


