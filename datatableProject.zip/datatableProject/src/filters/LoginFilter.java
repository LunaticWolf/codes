package filters;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

import daoOperation.Dao;


/**
 * Servlet Filter implementation class LoginFilter
 */
@WebFilter(filterName="LoginFilter", urlPatterns = {"/LoginServlet"})

public class LoginFilter implements Filter {
	Dao dao=new Dao();
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
	
		String name=request.getParameter("user").trim();
		String pass=request.getParameter("pass").trim();
		PrintWriter pw=response.getWriter();
		boolean check = false;
		
		try 
		{
			check=dao.fetchUser(name, pass);
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		if(check==true)
		{
			request.setAttribute("name", name);
			chain.doFilter(request, response);
		}
		else
		{
			pw.print("Wrong username or password");
			RequestDispatcher rd=request.getRequestDispatcher("login.html");
			rd.include(request, response);
		
		}
	}

	

	public void destroy() {
		// TODO Auto-generated method stub
	}

}
